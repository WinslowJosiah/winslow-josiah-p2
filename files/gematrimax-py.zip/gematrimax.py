import argparse, random, re, string, sys, unicodedata

# Function to print a specified error message to STDERR, then exit.
def error(errorMsg):
	sys.stderr.write("\nERROR: "+errorMsg)
	sys.exit()

# Function to calculate the gematria value of a word.
def gematria(word):
	word = word.upper()
	
	sum = 0
	for c in word:
		try:
			sum += string.ascii_uppercase.index(c) + 1
		except:
			pass
	
	return sum

# Function to convert a program in Cheat Mode to a list of commands.
def gmxCheatmodeToCmdList(cheatmodeProgram):
	pushCmd = re.compile(r"#(x[1-9a-f][0-9a-f]*|[1-9][0-9]*)")
	
	# Strip comments enclosed in quotes
	cheatmodeProgram = re.sub(r'"[^"]+("|$)', "", cheatmodeProgram)
	
	# Error out if trying to push 0
	if re.search(r"#(?=x?0)", cheatmodeProgram):
		error("Cannot push 0")
	# Error out if there is push command without argument
	if re.search(r"#(?!x[1-9a-f][0-9a-f]*|[1-9][0-9]*)", cheatmodeProgram, re.IGNORECASE):
		error("PUSH command without argument")
	
	cheatmodeArr = re.findall(r"(#(?:x[1-9a-f][0-9a-f]*|[1-9][0-9]*)|_?\[|[\]=?;+\-*/%!$&><\\)(}{,.:@])", cheatmodeProgram, re.IGNORECASE)
	
	cmdList = []
	for cmd in cheatmodeArr:
		regexMatch = re.match(pushCmd, cmd)
		if regexMatch:
			arg0 = regexMatch.group(1)
			if re.match(r"^x", arg0, re.IGNORECASE):
				arg0 = "0" + arg0
			arg0 = int(arg0, 0)
			cmdList.append({"cmd": "#", "argv": [arg0]})
		else:
			cmdList.append({"cmd": cmd, "argv": []})
	
	nestDepth = 0
	for cmd in cmdList:
		if cmd["cmd"] in ["[", "_["]:
			nestDepth += 1
		elif cmd["cmd"] in ["]"]:
			nestDepth -= 1
		if nestDepth < 0:
			error("Unbalanced loops")
	
	if nestDepth != 0:
		error("Unbalanced loops")
	
	return cmdList

# Function to convert a program in Gematrimax to a list of commands.
def gmxProgramToCmdList(program):
	program = re.sub(r"[\u0300-\u036f]", "", unicodedata.normalize("NFD", program))
	program = program.replace("'", "")
	programArr = re.findall(r"([a-z]+)", program, re.IGNORECASE)
	
	cheatmodeProgram = ""
	isPushArgument = False
	currentCommand = None
	for word in programArr:
		gematriaVal = gematria(word)
		if isPushArgument:
			currentCommand = ""
			cheatmodeProgram += str(gematriaVal)
			isPushArgument = False
		else:
			gematriaVal = ((gematriaVal - 1) % 26) + 1
			currentCommand = ["[", "_[", "]", "#", "=", "?", ";", "+", "-", "*", "/", "%", "!", "$", "&", ">", "<", "\\", ")", "(", "}", "{", ",", ".", ":", "@"][gematriaVal - 1]
			cheatmodeProgram += currentCommand
		if currentCommand == "#":
			isPushArgument = True
	
	return gmxCheatmodeToCmdList(cheatmodeProgram)

# Function to pop a value from the stack, and error if the value doesn't exist.
def popFromStack():
	a = stack.pop()
	if a is None:
		error("Can't pop from empty stack")
	return a

# Function to rotate an array from top to bottom.
def rotateTopToBottom(arr):
	return [arr[-1]] + arr[:-1]

# Function to rotate an array from bottom to top.
def rotateBottomToTop(arr):
	return arr[1:] + [arr[0]]

# Parse command-line options.
parser = argparse.ArgumentParser()
parser.add_argument(
	"program",
	help="file to run as Gematrimax code"
)
parser.add_argument(
	"-i", "--input",
	metavar="inputFile",
	help="take input from the specified file",
	required=False
)
parser.add_argument(
	"-c", "--cheatmode",
	help="interpret program in cheatmode",
	action="store_true",
	required=False
)
args = parser.parse_args()

# If an input file was specified on the command-line,
# then we use it for input.
# Otherwise, we use STDIN.
if args.input == None:
	inputStream = sys.stdin
else:
	inputStream = open(args.input, encoding="utf8")

# Open the program file, and convert it to a series of instructions
with open(args.program, encoding="utf8") as f:
	if args.cheatmode:
		cmdList = gmxCheatmodeToCmdList(f.read());
	else:
		cmdList = gmxProgramToCmdList(f.read());

# Most of this is ported from the JavaScript interpreter

instructionPointer = 0
stack = []
addressStack = []
eofReached = False

while True:
	try:
		currentCommand = cmdList[instructionPointer]
	except:
		break
	
	if currentCommand["cmd"] == "[":
		a = popFromStack()
		if a != 0:
			addressStack.append(instructionPointer)
		else:
			nestDepth = 0
			while True:
				instructionPointer += 1
				if cmdList[instructionPointer]["cmd"] in ["[", "_["]:
					nestDepth += 1
				elif cmdList[instructionPointer]["cmd"] in ["]"]:
					nestDepth -= 1
				if nestDepth < 0:
					break
	elif currentCommand["cmd"] == "_[":
		addressStack.append(instructionPointer)
	elif currentCommand["cmd"] == "]":
		loopbackPointer = addressStack.pop()
		if cmdList[loopbackPointer]["cmd"] == "[":
			instructionPointer = loopbackPointer - 1
		elif cmdList[loopbackPointer]["cmd"] == "_[":
			a = popFromStack()
			if a != 0:
				instructionPointer = loopbackPointer - 1
	elif currentCommand["cmd"] == "#":
		stack.append(currentCommand["argv"][0])
	elif currentCommand["cmd"] == "=":
		stack.append(len(stack))
	elif currentCommand["cmd"] == "?":
		a = popFromStack()
		if a < 0:
			error("Upper bound for random integer must be positive")
		stack.append(random.randrange(a))
	elif currentCommand["cmd"] == ";":
		popFromStack()
	elif currentCommand["cmd"] == "+":
		b = popFromStack()
		a = popFromStack()
		stack.append(a + b)
	elif currentCommand["cmd"] == "-":
		b = popFromStack()
		a = popFromStack()
		stack.append(a - b)
	elif currentCommand["cmd"] == "*":
		b = popFromStack()
		a = popFromStack()
		stack.append(a * b)
	elif currentCommand["cmd"] == "/":
		b = popFromStack()
		a = popFromStack()
		if b == 0:
			error("Can't divide by 0")
		stack.append(a // b)
	elif currentCommand["cmd"] == "%":
		b = popFromStack()
		a = popFromStack()
		if b == 0:
			error("Can't modulo by 0")
		stack.append(a % b)
	elif currentCommand["cmd"] == "!":
		a = popFromStack()
		stack.append(1 if a == 0 else 0)
	elif currentCommand["cmd"] == "$":
		b = popFromStack()
		a = popFromStack()
		stack.append(max(a, b))
	elif currentCommand["cmd"] == "&":
		a = popFromStack()
		stack.append(a)
		stack.append(a)
	elif currentCommand["cmd"] == ">":
		a = popFromStack()
		if not (a >= 0 and a < len(stack)):
			error("Stack index out of range")
		stack.append(stack[-1-a])
	elif currentCommand["cmd"] == "<":
		a = popFromStack()
		if not (a >= 0 and a < len(stack)):
			error("Stack index out of range")
		stack.append(stack[a])
	elif currentCommand["cmd"] == "\\":
		b = popFromStack()
		a = popFromStack()
		stack.append(b)
		stack.append(a)
	elif currentCommand["cmd"] == ")":
		stack = rotateTopToBottom(stack)
	elif currentCommand["cmd"] == "(":
		stack = rotateBottomToTop(stack)
	elif currentCommand["cmd"] == "}":
		a = popFromStack()
		if a == 0:
			error("Can't rotate 0 values")
		if a < 0:
			error("Can't rotate a negative number of values")
		if a > len(stack):
			a = len(stack)
		stack = stack[:-a] + rotateTopToBottom(stack[-a:])
	elif currentCommand["cmd"] == "{":
		a = popFromStack()
		if a == 0:
			error("Can't rotate 0 values")
		if a < 0:
			error("Can't rotate a negative number of values")
		if a > len(stack):
			a = len(stack)
		stack = stack[:-a] + rotateBottomToTop(stack[-a:])
	elif currentCommand["cmd"] == ",":
		if not eofReached:
			try:
				char = ord(inputStream.read(1))
				if args.input == None and char == 26:
					eofReached = True
				else:
					stack.append(char)
			except TypeError:
				eofReached = True
		if eofReached:
			stack.append(-1)
	elif currentCommand["cmd"] == ".":
		a = popFromStack()
		print(chr(a), end="", flush=True)
	elif currentCommand["cmd"] == ":":
		a = popFromStack()
		print(a, end="", flush=True)
	elif currentCommand["cmd"] == "@":
		break
	
	instructionPointer += 1